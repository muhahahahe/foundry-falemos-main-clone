Source files to change icons and names are in xcf, use GIMP to edit (https://www.gimp.org/)
Each image name contains the image overlay offsets (left, top, right, bottom) required to make it work:
Elegant 2_10+26+4+21
+ Name: Elegant 2
+ Offset left: 10
+ Offset top: 26
+ Offset right: 4
+ Offset bottom: 21